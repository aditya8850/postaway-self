import dotenv from "dotenv";
dotenv.config();//this is going to load all the env variables in our application
